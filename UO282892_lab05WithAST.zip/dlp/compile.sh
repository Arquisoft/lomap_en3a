
java -jar antlr-4.7-complete.jar src/parser/Cmm.g4 -package parser -no-listener
