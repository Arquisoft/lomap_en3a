package parser;

public class LexerHelper {
	
	public static int lexemeToInt(String str) {
		try {
			return Integer.parseInt(str);
		}
		catch(NumberFormatException e) {
			System.out.println(e);
		}
		return -1;
	}

	public static char lexemeToChar(String str) {
		String enclosedChar;
		try {
			// if there is a backslash
			if (str.charAt(1) == '\\') {
				// we take what is after the backslash
				enclosedChar = str.substring(2, str.length() - 1);
				if (enclosedChar.equals("n")) {
					return '\n';
				}
				else if (enclosedChar.equals("t")) {
					return '\t';
				}
				else {
					//It is an ASCII code
					return (char) Integer.parseInt(enclosedChar);
				}
			}
			return str.charAt(1);
		}
		catch(NumberFormatException e) {
			System.out.println(e);
		}
		return ' ';
	}

	public static double lexemeToReal(String str) {
		try {
			return Double.parseDouble(str);
		}
		catch(NumberFormatException e) {
			System.out.println(e);
		}
		return -1;
	}
	
}
