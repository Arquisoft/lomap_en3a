package parser;

import ast.*;

import java.util.ArrayList;
import java.util.List;

public class ParserHelper {

    public static Expression createArithOrMod(int line, int column, Expression left, Expression right, String operator) {
        Expression expression = null;
        switch (operator) {
            case "*", "/":
                expression = new Arithmetic(line, column, left, right, operator);
                break;
            case "%":
                expression = new Modulus(line, column, left, right);
                break;
        }
        return expression;
    }

    public static FuncDefinition assembleFunction(int line, int column, Type returnType,
                                                  String functionName, List<VarDefinition> parameters,
                                                  List<VarDefinition> varDefinitions,
                                                  List<Statement> statements) {
        List<Statement> body = new ArrayList<>(varDefinitions);
        body.addAll(statements);
        return new FuncDefinition(line, column,
                new FunctionType(line, column, returnType, parameters),
                functionName, body);

    }

    public static ArrayType createArray(int line, int column, Type type, int size) {
        ArrayType initialArray = new ArrayType(line, column, size, type);
        ArrayType arrayToReturn;
        if (! (initialArray.getElementsType() instanceof ArrayType)) {
            return initialArray;
        }
        arrayToReturn = (ArrayType) initialArray.getElementsType();
        Type nextType;
        ArrayType nextArray = initialArray;
        while ((nextType = nextArray.getElementsType()) instanceof ArrayType) {
            nextArray = (ArrayType) nextType;
        }
        initialArray.setElementsType(nextType);
        if (initialArray != nextArray) {
            nextArray.setElementsType(initialArray);
        }
        return arrayToReturn;
    }

    public static Program createProgram(List<Definition> definitions, FuncDefinition mainFunction) {
        List<Definition> instructions = new ArrayList<>(definitions);
        instructions.add(mainFunction);
        return new Program(instructions.get(0).getLine(), instructions.get(0).getColumn(), instructions);
    }
}
