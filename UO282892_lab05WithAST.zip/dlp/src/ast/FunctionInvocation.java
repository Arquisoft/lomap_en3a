package ast;
import java.util.List;

public class FunctionInvocation extends AbstractASTNode
implements Expression, Statement{
    private List<Expression> arguments;
    private Variable variable;

    public FunctionInvocation(int line, int column, List<Expression> arguments, Variable variable) {
        super(line, column);
        this.arguments = arguments;
        this.variable = variable;
    }

    public List<Expression> getArguments() {
        return arguments;
    }

    public Variable getVariable() {
        return variable;
    }

    @Override
    public String toString() {
        return "Function Invocation - name: " + variable.getName() + "; " + arguments.size() + " arguments";
    }
}
