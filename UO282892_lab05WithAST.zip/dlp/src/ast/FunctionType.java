package ast;
import java.util.List;

public class FunctionType extends AbstractASTNode
        implements Type{

    private Type returnType;
    private List<VarDefinition> parameters;

    public FunctionType(int line, int column, Type returnType, List<VarDefinition> parameters) {
        super(line, column);
        this.returnType = returnType;
        this.parameters = parameters;
    }

    public Type getReturnType() {
        return returnType;
    }

    public List<VarDefinition> getParameters() {
        return parameters;
    }

    @Override
    public String toString() {
        return "FunctionType - return type: [" + returnType + "]; " + parameters.size() + " parameters";
    }
}
