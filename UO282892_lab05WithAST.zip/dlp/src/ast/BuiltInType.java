package ast;
public interface BuiltInType extends Type{
}
