package ast;
public class IntegerType extends AbstractASTNode
        implements BuiltInType{
    public IntegerType(int line, int column) {
        super(line, column);
    }

    @Override
    public String toString() {
        return "IntegerType";
    }
}
