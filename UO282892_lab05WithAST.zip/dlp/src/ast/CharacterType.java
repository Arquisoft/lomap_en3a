package ast;
public class CharacterType extends AbstractASTNode
        implements BuiltInType{
    public CharacterType(int line, int column) {
        super(line, column);
    }

    @Override
    public String toString() {
        return "CharacterType";
    }
}
