package ast;

import java.util.LinkedList;

public class ArrayType extends AbstractASTNode
        implements Type{

    private int size;
    private Type elementsType;

    public ArrayType(int line, int column, int size, Type elementsType) {
        super(line, column);
        this.size = size;
        this.elementsType = elementsType;
    }

    public int getSize() {
        return size;
    }

    public Type getElementsType() {
        return elementsType;
    }

    public void setElementsType(Type elementsType) {
        this.elementsType = elementsType;
    }

    @Override
    public String toString() {
        return "ArrayType - type: [" + getElementsType() + "]; size: " + size;
    }
}
