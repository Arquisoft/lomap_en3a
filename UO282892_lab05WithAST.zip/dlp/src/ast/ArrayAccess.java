package ast;
public class ArrayAccess extends AbstractASTNode
implements Expression{

    private Expression left;
    private Expression right;

    public ArrayAccess(int line, int column, Expression left, Expression right) {
        super(line, column);
        this.left = left;
        this.right = right;
    }

    public Expression getLeft() {
        return left;
    }

    public Expression getRight() {
        return right;
    }

    @Override
    public String toString() {
        return "Array access - left: [" + left + "]; right: [" + right + "]";
    }
}
