package ast;
import java.util.List;

public class FuncDefinition extends AbstractDefinition{

    private List<Statement> statements;
    public FuncDefinition(int line, int column, FunctionType type, String name, List<Statement> statements) {
        super(line, column, type, name);
        this.statements = statements;
    }

    public List<Statement> getStatements() {
        return statements;
    }

    @Override
    public String toString() {
        return "Function definition - name: " + getName() + "; return type: ["
                + ((FunctionType) getType()).getReturnType() + "]; "
                + ((FunctionType) getType()).getParameters().size() + " parameters; "
                + statements.size() + " statements";
    }
}
