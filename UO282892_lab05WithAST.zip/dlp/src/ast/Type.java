package ast;
public interface Type extends ASTNode{
}
