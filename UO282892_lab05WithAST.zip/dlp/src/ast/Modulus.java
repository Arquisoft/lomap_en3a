package ast;
public class Modulus extends AbstractASTNode
implements Expression{

    private Expression left;
    private Expression right;

    public Modulus(int line, int column, Expression left, Expression right) {
        super(line, column);
        this.left = left;
        this.right = right;
    }

    public Expression getLeft() {
        return left;
    }

    public Expression getRight() {
        return right;
    }

    @Override
    public String toString() {
        return "Modulus; left: [" + left + "]; right: [" + right + "]";
    }
}
