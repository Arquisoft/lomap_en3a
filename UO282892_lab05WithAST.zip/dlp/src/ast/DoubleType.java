package ast;
public class DoubleType extends AbstractASTNode
        implements BuiltInType{
    public DoubleType(int line, int column) {
        super(line, column);
    }

    @Override
    public String toString() {
        return "DoubleType";
    }
}
