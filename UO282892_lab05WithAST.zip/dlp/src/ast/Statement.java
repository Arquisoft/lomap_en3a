package ast;
public interface Statement extends ASTNode{
}
